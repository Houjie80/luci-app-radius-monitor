const radmonContent=`
  <h3>RADIUS MONITOR V2</h3>
  <p>Aplikasi ini dipersembahkan untuk pengusaha hotspot pemula yang belum memiliki MikroTik.</p>
  <ul>
    <li>Author : Maizil</li>
    <li>Template : <a href="https://github.com/laksa19/mikhmonv3">Mikhmon V3</a></li>
    <li>Licence : <a href="https://github.com/maizil41/radmonv2/blob/master/LICENSE">GPLv2</a></li>
    <li>Website : <a href="https://github.com/maizil41/RadMonv2">maizil41/radmonv2</a></li>
    <li>Facebook : <a href="https://fb.com/maizil.41">fb.com/maizil</a></li>
  </ul>
  <p>Terima kasih untuk semua yang telah mendukung pengembangan RADMON.</p>
  <div>
    <i>Copyright &copy; 2024 Maizil [Mutiara-Wrt]</i>
  </div>
`;function loadContent(){document.getElementById('content').innerHTML=radmonContent}